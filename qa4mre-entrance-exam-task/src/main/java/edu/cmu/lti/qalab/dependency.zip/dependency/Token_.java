package edu.cmu.lti.qalab.dependency;

public class Token_ {
	String text;
	void setText(String t){
		text = t;
		
	}
	String getText(){
		return text;
	}
}
