package edu.cmu.lti.qalab.dependency;

public class sentenceDepScore {
	
}
